<?php
	//
	// imgStack 0.5
	// This is the php-script part of imgStack. It need to be in the exact same directory as the flash part imgStack.swf
	// More info: http://tint.de/imgStack-0-5
	// Contact: Tilman@tint.de
	//
	//
	// Get all the images in the folder and put the data out for imgStack.swf
	$imgPath = $_GET["imgPath"];

	if(substr($imgPath, 0, 1) != "/") {
		// relative imgPath, add this script's parent dir
		$parentPath = dirname(__FILE__);
		$imgPath = $parentPath."/"."$imgPath";
	} else {
		$parentPath = $_SERVER['DOCUMENT_ROOT'];
		$imgPath = $parentPath."/"."$imgPath";
	}

	$filecount = 0;
	$dirFiles = array(); // Initialize temporary arrays for sorting
	$handle = @opendir($imgPath) or die("fb=Directory \"$imgPath\" not found."); // Open directory

	// Loop through all directory entries, construct temporary array containing the filenames
	while($entry = readdir($handle)) {
		if(substr($entry, 0, 1) == ".") {
			// system file starting with .
		} else if(preg_match("/(.jpg|.gif|.png|.swf)$/i", $entry)) {
			$dirFiles[] = $entry;
		}
	}
	closedir($handle);
	sort($dirFiles);

	// Write out Var-Value-Pairs
	for($i=0; $i<count($dirFiles); $i++) {
		$file = $dirFiles[$i];
		$sizeArr = getimagesize($imgPath.$file);
		$width = $sizeArr[0];
		$height = $sizeArr[1];
		echo "&img{$i}File=$file&img{$i}W=$width&img{$i}H=$height&\n";
	}

	echo "&num=".count($dirFiles)."&";
	echo "&fb=ok&";
?>